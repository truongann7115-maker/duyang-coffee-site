#!/usr/bin/env python3
"""Generate a QR code that opens the deployed DUYANG marketing website."""
import sys
import qrcode

if len(sys.argv) != 2 or not sys.argv[1].startswith(("https://", "http://")):
    print('Usage: python qr_generator.py "https://your-real-site-url/"')
    raise SystemExit(2)

url = sys.argv[1]
qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_H, box_size=12, border=4)
qr.add_data(url)
qr.make(fit=True)
img = qr.make_image(fill_color="#160909", back_color="#ffffff").convert("RGB")
img.save("duyang-website-qr.png")
print("Saved duyang-website-qr.png for:", url)
