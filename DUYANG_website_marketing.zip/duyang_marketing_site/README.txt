DUYANG COFFEE — WEBSITE MARKETING

Nội dung:
- index.html: website marketing responsive tiếng Việt
- assets/duyang-packaging.png: hình bao bì do bạn cung cấp
- qr_generator.py: tạo QR từ URL website sau khi đăng tải

CÁCH ĐĂNG TẢI MIỄN PHÍ BẰNG GITHUB PAGES
1. Đăng nhập hoặc tạo tài khoản tại https://github.com
2. Tạo repository mới, ví dụ: duyang-coffee-site
3. Chọn Public; tạo repository.
4. Tải index.html và thư mục assets/ lên repository (giữ nguyên cấu trúc).
5. Vào Settings → Pages.
6. Trong Build and deployment, chọn Deploy from a branch; chọn branch main và folder /(root), rồi Save.
7. Chờ GitHub Pages triển khai. URL thường có dạng:
   https://TEN-TK-GITHUB.github.io/duyang-coffee-site/
   Thay TEN-TK-GITHUB bằng tên tài khoản thật của bạn.
8. Mở URL trên điện thoại để kiểm tra. Khi URL chạy ổn định, tạo QR bằng:
   python qr_generator.py "https://TEN-TK-GITHUB.github.io/duyang-coffee-site/"
   (cài thư viện nếu cần: pip install qrcode[pil])

LƯU Ý QUAN TRỌNG
- Chưa thể tạo QR hoạt động tới website thật trước khi biết URL được đăng tải.
- Không in QR placeholder lên bao bì. Sau khi có URL thật, hãy tạo QR mới.
- Trước khi công bố, thay email minh họa hello@duyangcoffee.vn trong index.html bằng email/điện thoại/kênh bán hàng thật.
- Kiểm tra lại thành phần, công dụng, chứng nhận, ngày sản xuất/hạn dùng và mọi tuyên bố quảng cáo để đảm bảo chính xác.
